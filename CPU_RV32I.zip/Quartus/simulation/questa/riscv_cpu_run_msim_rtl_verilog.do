transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/branchs.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/result_ext.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/reset_ff.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/datapath.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/riscv_cpu.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/adder.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/reg_file.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/alu.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/imm_extend.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/controller.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/maindecoder.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/alu_decoder.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/data_mem.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/mux3to1.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/pipe_ff.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/hazard_unit.v}
vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/instr_mem.v}

vlog  -work work +incdir+C:/Quartus/code {C:/Quartus/code/tb_riscv_cpu.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclonev_ver -L cyclonev_hssi_ver -L cyclonev_pcie_hip_ver -L rtl_work -L work -voptargs="+acc"  tb_riscv_cpu

add wave *
view structure
view signals
run -all
