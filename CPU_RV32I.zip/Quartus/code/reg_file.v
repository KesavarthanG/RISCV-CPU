module reg_file #(parameter DATA_WIDTH = 32) (
    input       clk,
    input       wr_en,
    input       [4:0] rd_addr1, rd_addr2, wr_addr,
    input       [DATA_WIDTH-1:0] wr_data,
    output reg  [DATA_WIDTH-1:0] rd_data1,
    output reg  [DATA_WIDTH-1:0] rd_data2,
    output [31:0] x5,x6
);

reg [DATA_WIDTH-1:0] reg_file_arr [0:31];
assign x5 = reg_file_arr[5];
assign x6 = reg_file_arr[6];

integer i;
initial begin
    for (i = 0; i < 32; i = i + 1)
        reg_file_arr[i] = 0;
end

// ================= WRITE : posedge =================
always @(posedge clk) begin
    if (wr_en && (wr_addr != 5'b0))
        reg_file_arr[wr_addr] <= wr_data;
end

// ================= READ : negedge =================
always @(negedge clk) begin
    rd_data1 <= (rd_addr1 != 0) ? reg_file_arr[rd_addr1] : 32'b0;
    rd_data2 <= (rd_addr2 != 0) ? reg_file_arr[rd_addr2] : 32'b0;
end

endmodule
