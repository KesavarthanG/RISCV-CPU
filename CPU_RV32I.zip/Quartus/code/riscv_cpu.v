module riscv_cpu(
    input  clk,
    input  rst,
    output [31:0] PC,
	 output [31:0] result,
	 output [31:0] SrcA,SrcB,
	 output [31:0] Mem_Wraddr,
	 output [31:0]Mem_Wrdata,
	 output [31:0] x5,x6,
	 output [4:0] wr_add ,
	 output [31:0] alu2input,
	 output [31:0] PCTargetE,
	 output [31:0] InstrD,
	 output [1:0] PCSelE,
	 output [31:0] Alu1st_input,
	 output [1:0] ForwardAE,ForwardBE,
	 output [4:0] RdE,Rs1E,Rs2E,
	 output Stall,
	 output FlushD,FlushE
);


wire [3:0] ALUControl;
wire [2:0] ImmSrc;
wire [1:0] resultsrc;
wire RegWrite;
wire ALUSrcB;
wire Zero;
wire [31:0] Immext;

wire [31:0] instr;
wire[31:0] PCPlus4F;
assign wr_add = instr[11:7];
wire [1:0] ALUSrcA;
//wire Stall;
wire [31:0] ReadDataM_inp;
wire MemWrite,MemWriteM;
wire isLoadD;
wire [2:0] funct3M;
wire isJalrD,BranchD,JumpD;
instr_mem instrmem (
    .instr_addr(PC),
    .instr(instr)
);
// Datapath
datapath dp (
    .clk(clk),
    .rst(rst),
    .Instr(instr),
    .PC(PC),
	 .result(result),
    .RegWrite(RegWrite),
    .ImmSrc(ImmSrc),
    .ALUSrcB(ALUSrcB),
    .ALUResultM(Mem_Wraddr),
	 .WriteDataM(Mem_Wrdata),
    .Zero(Zero),
	 .resultsrc(resultsrc),
	 .ALUControl(ALUControl),
	 .ReadDataM_inp(ReadDataM_inp),
	 .SrcA(SrcA),
	 .SrcB(SrcB),
	 .ALUSrcA(ALUSrcA),
	 .x5(x5),
	 .x6(x6),
	 .alu2input(alu2input),
	 .PCTargetE(PCTargetE),
	 .Immext( Immext),
	 .PCPlus4F(PCPlus4F),
	 .MemWrite(MemWrite),
	 .MemWriteM(MemWriteM),
	 .InstrD(InstrD),
	 .isLoadD(isLoadD),
	 .funct3M(funct3M),
	 .PCSelE(PCSelE),
	 .isJalrD(isJalrD),
	 .JumpD(JumpD),
	 .BranchD(BranchD),
	 .Alu1st_input(Alu1st_input),
	 .ForwardAE(ForwardAE),
	 .ForwardBE(ForwardBE),
	 .RdE(RdE),
	 .Rs1E(Rs1E),
	 .Rs2E(Rs2E),
	 .Stall(Stall),
	 .FlushD(FlushD),
	 .FlushE(FlushE)
);
controller c(
	.Instr(InstrD),
	.ALUSrcB(ALUSrcB),
	.ImmSrc(ImmSrc),
	.ALUControl(ALUControl),
	.ResultSrc(resultsrc),
	.MemWrite(MemWrite),
	.RegWrite(RegWrite),
	.ALUSrcA(ALUSrcA),
	.isLoadD(isLoadD),
	.isJalrD(isJalrD),
	.JumpD(JumpD),
	.BranchD(BranchD)
);
data_mem datamem(
          .clk(clk),
			 .write_en(MemWriteM),
			 .Mem_Addr(Mem_Wraddr),
			 .wr_data(Mem_Wrdata),
			 .rd_data_mem(ReadDataM_inp),
			 .funct3(funct3M) 
);

endmodule
