module controller(
	input [31:0] Instr,
	output ALUSrcB,
	output [2:0] ImmSrc,
	output [3:0] ALUControl,
	output PCSrc,
	output [1:0] ResultSrc,
	output MemWrite,
	output RegWrite,
	output [1:0] ALUSrcA,
	output isLoadD,
	output isJalrD,
	output BranchD,JumpD
);


wire [1:0] ALUop;
assign isLoadD = (Instr[6:0] == 7'b0000011);
maindecoder md(
	.opcode(Instr[6:0]),
	.ALUSrcB(ALUSrcB),
	.ImmSrc(ImmSrc),
	.RegWrite(RegWrite),
	.Branch(BranchD),
	.Jump(JumpD),
	.resultSrc(ResultSrc),
	.MemWrite(MemWrite),
	.ALUop(ALUop),
	.ALUSrcA(ALUSrcA)
);
alu_decoder alu(
	.funct3(Instr[14:12]),
	.funct7_5(Instr[30]),
	.op5(Instr[5]),
	.ALUop(ALUop),
	.ALUControl(ALUControl)
);

assign isJalrD = (Instr[6:0] == 7'b1100111);
endmodule