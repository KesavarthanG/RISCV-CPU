module branchs(
    input        zero,
    input  [2:0] funct3,
    output reg   branch
);

always @(*) begin
    branch = 1'b0;

    case (funct3)
        3'b000: branch =  zero;   // BEQ
        3'b001: branch = ~zero;   // BNE

        3'b100: branch = ~zero;   // BLT   
        3'b101: branch =  zero;   // BGE

        3'b110: branch = ~zero;   // BLTU  
        3'b111: branch =  zero;   // BGEU

        default: branch = 1'b0;
    endcase
end

endmodule
