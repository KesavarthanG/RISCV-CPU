module result_ext(
    input  [31:0] data_in,       // rd_data_mem
    input  [31:0] Mem_Wraddr,     // effective byte address
    input    isLoadM,
    input  [2:0]  funct3,
    output reg [31:0] final_rd_data_mem 
);

wire [1:0] byte_offset;
assign byte_offset = Mem_Wraddr[1:0];

always @(*) begin
    // default (important: no latch)
    final_rd_data_mem = data_in;

    if (isLoadM) begin   // LOAD
        case (funct3)

            // -------- LB --------
            3'b000: begin
                case (byte_offset)
                    2'b00: final_rd_data_mem = {{24{data_in[7]}},  data_in[7:0]};
                    2'b01: final_rd_data_mem = {{24{data_in[15]}}, data_in[15:8]};
                    2'b10: final_rd_data_mem = {{24{data_in[23]}}, data_in[23:16]};
                    2'b11: final_rd_data_mem = {{24{data_in[31]}}, data_in[31:24]};
                endcase
            end

            // -------- LH --------
            3'b001: begin
                if (byte_offset[1] == 1'b0)
                    final_rd_data_mem = {{16{data_in[15]}}, data_in[15:0]};
                else
                    final_rd_data_mem = {{16{data_in[31]}}, data_in[31:16]};
            end

            // -------- LW --------
            3'b010: final_rd_data_mem = data_in;

            // -------- LBU --------
            3'b100: begin
                case (byte_offset)
                    2'b00: final_rd_data_mem = {24'b0, data_in[7:0]};
                    2'b01: final_rd_data_mem = {24'b0, data_in[15:8]};
                    2'b10: final_rd_data_mem = {24'b0, data_in[23:16]};
                    2'b11: final_rd_data_mem = {24'b0, data_in[31:24]};
                endcase
            end

            // -------- LHU --------
            3'b101: begin
                if (byte_offset[1] == 1'b0)
                    final_rd_data_mem = {16'b0, data_in[15:0]};
                else
                    final_rd_data_mem = {16'b0, data_in[31:16]};
            end

            default: final_rd_data_mem = data_in;
        endcase
    end
end

endmodule
