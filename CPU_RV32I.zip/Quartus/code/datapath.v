module datapath(
	input clk,rst,
	input  [31:0] Instr,
	input RegWrite,
	input [1:0] resultsrc,
	input [3:0] ALUControl,
	input [2:0] ImmSrc,
	input ALUSrcB,
	input [1:0] ALUSrcA,
	input isLoadD,
	input [31:0] ReadDataM_inp,
	input MemWrite,
	output MemWriteM,
	output [31:0] ALUResultM,WriteDataM,
	output [31:0] PC,
	output [31:0] result,
	output Zero,
	output [31:0] SrcA,SrcB,     // ID stage
	output [31:0] x5,x6,
	output [31:0] Alu1st_input,
	output [31:0] alu2input,
	output [31:0] PCTargetE,
	output [31:0] Immext,
	output [31:0] PCPlus4F,
	output [31:0] InstrD,
	output [2:0] funct3M,
	output [1:0] PCSelE,
	input isJalrD,
	input BranchD,JumpD,
	output [4:0] RdE,Rs1E,Rs2E,
	output [1:0] ForwardAE,ForwardBE,
	output Stall,
	output FlushD,FlushE
);

reg [31:0] PCNext;
wire [4:0] RdD,Rs1D,Rs2D;
assign RdD = InstrD[11:7];
assign Rs1D =  InstrD[19:15];
assign Rs2D =  InstrD[24:20];
wire [2:0] funct3D = InstrD[14:12];
wire [4:0] RdM;
wire RegWriteM;
wire [31:0] SrcAE_H,SrcBE_H;
wire [31:0] WriteDataE;
wire label;
wire [31:0] resultW;
wire [31:0] ALUResultE;
wire [31:0] PCD, PCPlus4D;
wire [31:0] SrcAE, SrcBE, ImmExtE,PCE,PCPlus4E;
wire [2:0] funct3E;
wire MemWriteE,RegWriteE;
wire isLoadE;
wire [3:0]  ALUControlE;
wire        ALUSrcBE;
wire [1:0]  ALUSrcAE,resultsrcE;
wire isJalrE,JumpE,BranchE;
wire [4:0] RdW;
wire RegWriteW;
wire [31:0] PCPlus4M;
wire[31:0] ReadDataM;
wire [1:0] resultsrcM;
wire isLoadM;

// ================= IF =================
reset_ff #(32) pcreg(.clk(clk), .rst(rst), .en(!Stall) , .d(PCNext), .q(PC));
adder pcadd4(PC, 32'd4, PCPlus4F);


always @(*) begin
PCNext = PCPlus4F; 
    case (PCSelE)
        2'b00: PCNext = PCPlus4F;
        2'b01: PCNext = PCTargetE;
        2'b10: PCNext = {ALUResultE[31:1],1'b0};
        default: PCNext = PCPlus4F;
    endcase
end
// ================= IF/ID FF=================

pipe_ff #(32) IFID_pc    (.clk(clk),    .d(PC),         .q(PCD),       .clear(FlushD), .en(!Stall));
pipe_ff #(32) IFID_pc4   (.clk(clk),    .d(PCPlus4F),   .q(PCPlus4D),  .clear(FlushD), .en(!Stall));
pipe_ff #(32) IFID_instr (.clk(clk),    .d(Instr),      .q(InstrD),    .clear(FlushD), .en(!Stall));
// ================= ID =================

reg_file rf (
	.clk(clk),
	.wr_en(RegWriteM),  
	.rd_addr1(InstrD[19:15]),
	.rd_addr2(InstrD[24:20]),
	.wr_addr(RdM),
	.wr_data(result),
	.rd_data1(SrcA),    
	.rd_data2(SrcB),    
	.x5(x5),
	.x6(x6)
);

imm_extend imm (
	.instr(InstrD[31:7]),
	.immsrc(ImmSrc),
	.immext(Immext)    
);

// ================= ID / EX FF =================

pipe_ff #(32) IDEX_rs1    (.clk(clk), .d(SrcA),       .q(SrcAE),   .clear(FlushE), .en(1'b1));
pipe_ff #(32) IDEX_rs2    (.clk(clk), .d(SrcB),       .q(SrcBE),   .clear(FlushE), .en(1'b1));
pipe_ff #(32) IDEX_imm    (.clk(clk), .d(Immext),     .q(ImmExtE), .clear(FlushE), .en(1'b1));
pipe_ff #(32) IDEX_pc     (.clk(clk), .d(PCD),        .q(PCE),     .clear(FlushE), .en(1'b1));     
pipe_ff #(32) IDEX_pc4    (.clk(clk), .d(PCPlus4D),   .q(PCPlus4E),.clear(FlushE), .en(1'b1));
pipe_ff #(5)  IDEX_RdD    (.clk(clk), .d(RdD),        .q(RdE),     .clear(FlushE), .en(1'b1));
pipe_ff #(3) IDEX_funct3  (.clk(clk), .d(funct3D),    .q(funct3E), .clear(FlushE), .en(1'b1));
pipe_ff #(5)  IDEX_Rs1    (.clk(clk), .d(Rs1D),       .q(Rs1E),    .clear(FlushE), .en(1'b1));
pipe_ff #(5)  IDEX_Rs2    (.clk(clk), .d(Rs2D),       .q(Rs2E),    .clear(FlushE), .en(1'b1));

//Controls

pipe_ff #(4)  IDEX_ALU       (.clk(clk), .d(ALUControl), .q(ALUControlE),  .clear(FlushE), .en(1'b1));
pipe_ff #(1)  IDEX_ALUB      (.clk(clk), .d(ALUSrcB),    .q(ALUSrcBE),     .clear(FlushE), .en(1'b1));
pipe_ff #(2)  IDEX_ALUA      (.clk(clk), .d(ALUSrcA),    .q(ALUSrcAE),     .clear(FlushE), .en(1'b1));
pipe_ff #(1)  IDEX_MemWrite  (.clk(clk), .d(MemWrite),   .q(MemWriteE),    .clear(FlushE), .en(1'b1));
pipe_ff #(1)  IDEX_RegWrite  (.clk(clk), .d(RegWrite),   .q(RegWriteE),    .clear(FlushE), .en(1'b1));
pipe_ff #(2)  IDEX_Resultsr  (.clk(clk), .d(resultsrc),  .q(resultsrcE),   .clear(FlushE), .en(1'b1));
pipe_ff #(1) IDEX_isLoad     (.clk(clk), .d(isLoadD),    .q(isLoadE),      .clear(FlushE), .en(1'b1));
pipe_ff #(1) IDEX_isJump     (.clk(clk), .d(JumpD),      .q(JumpE),        .clear(FlushE), .en(1'b1));
pipe_ff #(1) IDEX_isBranch   (.clk(clk), .d(BranchD),    .q(BranchE),      .clear(FlushE), .en(1'b1));
pipe_ff #(1) IDEX_isJalr     (.clk(clk), .d(isJalrD),    .q(isJalrE),      .clear(FlushE), .en(1'b1));
// ================= EX =================

hazard_unit u1(
	.Rs1E (Rs1E),
	.Rs2E(Rs2E),
	.Rs1D(Rs1D),
	.Rs2D(Rs2D),
	.RdM(RdM),
	.RdW(RdW),
	.RdE(RdE),
	.isLoadE(isLoadE),
	.RegWriteM(RegWriteM),
	.RegWriteW(RegWriteW),
	.ForwardAE(ForwardAE),
	.ForwardBE(ForwardBE),
	.Stall(Stall),
	.PCSelE(PCSelE),
	.FlushD(FlushD),
	.FlushE(FlushE)
);

 mux3to1 SrcAmux_1(
	.a(SrcAE),            
	.b(resultW),         
	.c(ALUResultM),
	.sel(ForwardAE),    
	.y(SrcAE_H)
);

mux3to1 SrcAmux_2(
	.a(PCE),            
	.b(SrcAE_H),          
	.c(32'b0),
	.sel(ALUSrcAE),     
	.y(Alu1st_input)
);

 mux3to1 SrcBmux_1(
	.a(SrcBE),             
	.b(resultW),          
	.c(ALUResultM),
	.sel(ForwardBE),   
	.y(SrcBE_H)
);

assign alu2input  = (ALUSrcBE) ? ImmExtE : SrcBE_H;   
assign WriteDataE = SrcBE_H;                          

alu alu_unit (
    .a(Alu1st_input),
    .b(alu2input),
    .ALUControl(ALUControlE), 
    .ALUresult(ALUResultE),
    .Zero(Zero)
);

branchs br(
	.zero(Zero),
	.funct3(funct3E),
	.branch(label)
);
assign PCSelE =
    (JumpE && isJalrE)           ? 2'b10 :
    (JumpE || (BranchE & label)) ? 2'b01 :
                                   2'b00;

adder pctarget(PCE, ImmExtE, PCTargetE); 
// ================= EX / DM FF  <<< ADDED =================



pipe_ff #(32) EXDM_pc4       (.clk(clk), .d(PCPlus4E),   .q(PCPlus4M),   .clear(1'b0), .en(1'b1));
pipe_ff #(5)  EXDM_RdD       (.clk(clk), .d(RdE),        .q(RdM),        .clear(1'b0), .en(1'b1));
pipe_ff #(32) EXDM_WrDATA    (.clk(clk), .d(WriteDataE), .q(WriteDataM), .clear(1'b0), .en(1'b1));
pipe_ff #(32) EXDM_ALUres    (.clk(clk), .d(ALUResultE), .q(ALUResultM), .clear(1'b0), .en(1'b1));
pipe_ff #(3)  EXDM_funct3    (.clk(clk), .d(funct3E),    .q(funct3M),    .clear(1'b0), .en(1'b1));

//controls


pipe_ff #(1)  EXDM_MemWrite  (.clk(clk), .d(MemWriteE),   .q(MemWriteM),  .clear(1'b0), .en(1'b1));
pipe_ff #(1)  EXDM_RegWrite  (.clk(clk), .d(RegWriteE),   .q(RegWriteM),  .clear(1'b0), .en(1'b1));
pipe_ff #(2)  EXDM_Resultsr  (.clk(clk), .d(resultsrcE),  .q(resultsrcM), .clear(1'b0), .en(1'b1));
pipe_ff #(1)  EXDM_isLoad    (.clk(clk), .d(isLoadE),     .q(isLoadM),    .clear(1'b0), .en(1'b1));

// ================= DM =================

result_ext final(
	.data_in(ReadDataM_inp),
	.Mem_Wraddr(ALUResultM),
	.isLoadM(isLoadM),
	.funct3(funct3M),
	.final_rd_data_mem(ReadDataM)
);
mux3to1 resultmux(
	.a(ALUResultM),
	.b(ReadDataM),
	.c(PCPlus4M),
	.sel(resultsrcM),
	.y(result)
);
// ================= DM/WB FF =================

pipe_ff #(5)  DMWB_RdD        (.clk(clk), .d(RdM),        .q(RdW),       .clear(1'b0),  .en(1'b1));
pipe_ff #(32) DMWB_res        (.clk(clk), .d(result),     .q(resultW),   .clear(1'b0),  .en(1'b1));
pipe_ff #(1)  DMWB_RegWrite  (.clk(clk), .d(RegWriteM),   .q(RegWriteW), .clear(1'b0),  .en(1'b1));

// ================= WB=================


endmodule
