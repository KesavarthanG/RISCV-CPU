module data_mem #(
    parameter DATA_WIDTH = 32,
    parameter MEM_SIZE   = 64
)(
    input                  clk,
    input                  write_en,
    input      [2:0]       funct3,      // 000=SB, 001=SH, 010=SW
    input      [31:0]      Mem_Addr,
    input      [31:0]      wr_data,
    output     [31:0]      rd_data_mem
);

reg [31:0] memory_array [0:MEM_SIZE-1];

wire [31:0] word_addr   = Mem_Addr[31:2] % MEM_SIZE;
wire [1:0]  byte_offset = Mem_Addr[1:0];

// READ (combinational)
assign rd_data_mem = memory_array[word_addr];

// WRITE
always @(posedge clk) begin
    if (write_en) begin
        case (funct3)

            // ---------------- SB ----------------
            3'b000: begin
                case (byte_offset)
                    2'b00: memory_array[word_addr][7:0]   <= wr_data[7:0];
                    2'b01: memory_array[word_addr][15:8]  <= wr_data[7:0];
                    2'b10: memory_array[word_addr][23:16] <= wr_data[7:0];
                    2'b11: memory_array[word_addr][31:24] <= wr_data[7:0];
                endcase
            end

            // ---------------- SH ----------------
            3'b001: begin
                if (byte_offset[1] == 1'b0) begin
                    memory_array[word_addr][15:0]  <= wr_data[15:0];
                end else begin
                    memory_array[word_addr][31:16] <= wr_data[15:0];
                end
            end

            // ---------------- SW ----------------
            3'b010: begin
                memory_array[word_addr] <= wr_data;
            end

            default: begin
                memory_array[word_addr] <= memory_array[word_addr];
            end
        endcase
    end
end

endmodule
