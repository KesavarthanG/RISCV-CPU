module maindecoder(
input [6:0] opcode,
output ALUSrcB,
output [2:0] ImmSrc,
output RegWrite,
output Branch,
output Jump,
output [1:0]resultSrc,
output MemWrite,
output [1:0] ALUop,
output [1:0] ALUSrcA
);
reg [13:0] controls;
always@(*) begin 
			case(opcode)
			7'b0000011: controls = 14'b1_000_1_0_01_0_00_0_01; //lw
			7'b0100011: controls = 14'b0_001_1_1_xx_0_00_0_01; // sw
			7'b0110011: controls = 14'b1_xxx_0_0_00_0_10_0_01; // R-type  -->   two inputs(both reg) do operation and store in reg
			7'b1100011: controls = 14'b0_010_0_0_xx_1_01_0_01; // beq
			7'b0010011: controls = 14'b1_000_1_0_00_0_10_0_01; //addi &slti  -->two inputs(one reg , one imm) do operation and store in reg
			7'b1101111: controls = 14'b1_011_x_0_10_0_xx_1_01; //jal
			7'b0110111: controls = 14'b1_100_1_0_00_0_00_0_10; //lui
			7'b0010111: controls = 14'b1_100_1_0_00_0_00_0_00; //auipc 
			7'b1100111: controls = 14'b1_000_1_0_10_0_00_1_01; //jalr
			default:    controls = 14'b0_000_0_0_00_0_00_0_01; //nop
			endcase
end
assign {RegWrite,ImmSrc,ALUSrcB,MemWrite,resultSrc,Branch,ALUop,Jump,ALUSrcA} = controls;
endmodule