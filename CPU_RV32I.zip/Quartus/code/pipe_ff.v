module pipe_ff #(parameter WIDTH = 32)(
    input               clk,
    input               clear,   // synchronous clear
    input               en,      // enable (stall control)
    input  [WIDTH-1:0]  d,
    output reg [WIDTH-1:0] q
);

always @(posedge clk) begin
    if (clear)
        q <= {WIDTH{1'b0}};   
    else if (en)
        q <= d;              
end

endmodule
