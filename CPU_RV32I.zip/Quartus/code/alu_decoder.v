module alu_decoder(
input [2:0] funct3,
input funct7_5,
input op5,
input [1:0] ALUop,
output reg [3:0] ALUControl
);
always @(*)
		begin 
		case(ALUop)
		2'b00: ALUControl = 4'b0000;
		2'b01: begin
					 case (funct3)
						  3'b000,
						  3'b001: ALUControl = 4'b0001; // BEQ, BNE → SUB

						  3'b100,
						  3'b101: ALUControl = 4'b0101; // BLT, BGE → SLT (signed)

						  3'b110,
						  3'b111: ALUControl = 4'b0110; // BLTU, BGEU → SLTU (unsigned)

						  default: ALUControl = 4'b0001;
					 endcase
				end

		2'b10: begin
				 case (funct3)
				 3'b000: begin 
							if(op5 && funct7_5) ALUControl = 4'b0001;  //SUB
							else ALUControl = 4'b0000;   // ADD
							end  
				 3'b010: ALUControl = 4'b0101;  //SLTI & SLT
				 3'b110: ALUControl = 4'b0010;  //ORI  & OR
				 3'b111: ALUControl = 4'b0011; //ANDI  & AND
				 3'b100: ALUControl = 4'b0100;  //XORI & XOR
				 3'b011: ALUControl = 4'b0110; //SLTU & SLTIU
				 3'b001: ALUControl = 4'b0111; //SLL AND SLLI
				 3'b101: begin 
								if(funct7_5) ALUControl = 4'b1001; // SRA & SRAI
								else  ALUControl = 4'b1000; // SRL & SRLI
							end 
				 
				 endcase
				 end
		default: ALUControl = 4'b0000;
		endcase
		end
endmodule