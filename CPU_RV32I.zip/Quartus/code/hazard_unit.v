module hazard_unit(
    input  [4:0] Rs1E, Rs2E,
    input  [4:0] RdM, RdW,RdE,
	 input  [4:0] Rs1D,Rs2D,
	 input  [1:0] PCSelE,
	 input isLoadE,
    input        RegWriteM, RegWriteW,
    output reg [1:0] ForwardAE, ForwardBE,
	 output FlushD,FlushE,
	 output Stall
);

always @(*) begin
    // ---------- ForwardAE (rs1) ----------
    if ((RegWriteM) && (RdM != 0) && (RdM == Rs1E))
        ForwardAE = 2'b10;
    else if ((RegWriteW) && (RdW != 0) && (RdW == Rs1E))
        ForwardAE = 2'b01;
    else
        ForwardAE = 2'b00;

    // ---------- ForwardBE (rs2) ----------
    if ((RegWriteM) && (RdM != 0) && (RdM == Rs2E))
        ForwardBE = 2'b10;
    else if ((RegWriteW) && (RdW != 0) && (RdW == Rs2E))
        ForwardBE = 2'b01;
    else
        ForwardBE = 2'b00;
end
assign Stall = 
    ((isLoadE === 1'b1) &&
     (RdE != 0) &&
     ((RdE == Rs1D) || (RdE == Rs2D)))
    ? 1'b1 : 1'b0;
	 
assign FlushD = (PCSelE != 0) ? 1'b1 : 1'b0;
assign FlushE = (PCSelE != 0 || Stall) ? 1'b1 : 1'b0;
endmodule
