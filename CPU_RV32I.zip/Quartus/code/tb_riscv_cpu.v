module tb_riscv_cpu;

reg clk;
reg rst;
wire [31:0] PC;
wire[31:0] x5,x6;
wire [31:0] result;
wire [31:0] SrcA,SrcB;
wire [31:0] Mem_Wraddr;
wire [1:0] ForwardAE,ForwardBE;
wire Stall;
//wire [3:0] ALUControl;
//wire [2:0] ImmSrc;
//wire [1:0] resultsrc;
//wire RegWrite;
//wire ALUSrcB,Zero;
wire [31:0]Mem_Wrdata;
wire [4:0] wr_add;
wire [31:0] alu2input;
wire [31:0] PCTarget;
//wire [31:0] Immext;
wire [31:0] InstrD;
wire [1:0] PCSelE;
wire [31:0]  Alu1st_input;
wire [4:0] RdE,Rs1E,Rs2E;
wire FlushD,FlushE;
riscv_cpu dut (
    .clk(clk),
    .rst(rst),
    .PC(PC),
	 .result(result),
	 .SrcA(SrcA),
	 .SrcB(SrcB),
	 .Mem_Wraddr(Mem_Wraddr),
	 //.ALUControl(ALUControl),
	 //.ImmSrc(ImmSrc),
	 //.resultsrc(resultsrc),
	 //.RegWrite(RegWrite),
	 //.ALUSrcB(ALUSrcB),
	 //.Zero(Zero),
	 .Mem_Wrdata(Mem_Wrdata),
	 .x5(x5),
	 .x6(x6),
	 .wr_add (wr_add ),
	 .alu2input(alu2input),
	 .PCTargetE(PCTarget),
	 //.Immext(Immext),
	 .InstrD(InstrD),
	 .PCSelE(PCSelE),
	 .Alu1st_input(Alu1st_input),
	 .ForwardAE(ForwardAE),
	 .ForwardBE(ForwardBE),
	 .RdE(RdE),
	 .Rs1E(Rs1E),
	 .Rs2E(Rs2E),
	 .Stall(Stall),
	 .FlushD(FlushD),
	 .FlushE(FlushE)
	 
);

always #5 clk = ~clk;

initial begin
    clk = 0;
    rst = 1;
    #4 rst = 0;
    #800 $stop;
end

endmodule
