module alu #(parameter DATA_WIDTH = 32)(
	input [DATA_WIDTH-1:0] a,
	input [DATA_WIDTH-1:0] b,
	input [3:0] ALUControl,
	output reg[DATA_WIDTH-1:0]  ALUresult,
	output Zero
);

	always @(a,b,ALUControl) begin 
	case(ALUControl) 
	4'b0000: ALUresult = a + b;
	4'b0001: ALUresult = a + (~b) +1;
	4'b0010: ALUresult = a | b;
	4'b0011: ALUresult = a & b;
	4'b0100: ALUresult = a ^ b;
	4'b0101: ALUresult = ($signed(a) < $signed(b)) ? 32'd1 : 32'd0;
	4'b0110: ALUresult = ((a) < (b)) ? 32'd1 : 32'd0;
	4'b0111: ALUresult = a << (b[4:0]); //sll & slli
	4'b1000: ALUresult = a >> (b[4:0]); //srl & srli
	4'b1001: ALUresult = $signed(a) >>> b[4:0]; //sra & srai
	default: ALUresult = {DATA_WIDTH{1'b0}};
	endcase
	end
assign Zero = (ALUresult == 0);	
endmodule